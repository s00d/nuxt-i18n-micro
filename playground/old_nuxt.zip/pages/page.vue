<template>
  <div>
    <p>{{ t('key2.key2.key2.key2.key2') }}</p>
    <p>Current Locale: {{ currentLocale }}</p>

    <div>
      {{ t('welcome', { username: 'Alice', unreadCount: 5 }) }}
    </div>
    <div>
      {{ tc('apples', 10) }}
    </div>

    <!-- Links for switching locales -->
    <div>
      <button
        v-for="locale in locales"
        :key="locale"
        :disabled="locale === currentLocale"
        @click="switchLocale(locale)"
      >
        Switch to {{ locale }}
      </button>
    </div>

    <div>
      <NuxtLink :to="localeRoute('index')">
        Go to Index
      </NuxtLink>
    </div>
  </div>
</template>

<script setup>
const { locale, availableLocales, t, tc, setLocale } = useI18n()
const router = useRouter()
const localeRoute = useLocalePath()

const currentLocale = locale.value
const locales = availableLocales

const switchLocale = async (newLocale) => {
  if (newLocale !== currentLocale) {
    await setLocale(newLocale)
    const path = useSwitchLocalePath(newLocale)
    router.push(path)
  }
}
</script>
