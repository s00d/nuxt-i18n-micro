<template>
  <div>
    <p>{{ $t('key1.key1.key1.key1.key1') }}</p>
    <p>Current Locale: {{ locale }}</p>

    <!-- Links for switching locales -->
    <div>
      <button
        v-for="locale in locales"
        :key="locale"
        :disabled="locale === currentLocale"
        @click="switchLocale(locale)"
      >
        Switch to {{ locale }}
      </button>
    </div>

    <div>
      <NuxtLink :to="localeRoute({ name: 'page' })">Go to Page</NuxtLink>
    </div>

    <div v-for="key in generatedKeys" :key="key">
      <p>{{ key }}: {{ $t(key) }}</p>
    </div>
  </div>
</template>

<script setup>
const { locale, availableLocales, setLocale } = useI18n()
const route = useRoute()
const router = useRouter()
const localeRoute = useLocalePath()

const currentLocale = locale.value
const locales = availableLocales

const switchLocale = async (newLocale) => {
  if (newLocale !== currentLocale) {
    await setLocale(newLocale)
    const path = useSwitchLocalePath(newLocale)
    router.push(path)
  }
}

// Function to generate random prefix
function generateRandomPrefix(maxKeys = 10) {
  return `key${Math.floor(Math.random() * maxKeys)}`
}

// Function to generate keys with random prefix up to a certain depth
function generateKeys(depth, maxKeys = 10) {
  const keys = []
  const generate = (currentKey, currentDepth) => {
    if (currentDepth === 0) {
      keys.push(currentKey)
      return
    }
    for (let i = 0; i < maxKeys; i++) {
      const newKey = `key${i}`
      generate(`${currentKey}.${newKey}`, currentDepth - 1)
    }
  }

  // Start with a randomly generated prefix
  const prefix = generateRandomPrefix(maxKeys)
  generate(prefix, depth)
  return keys
}

// Generate keys up to the maximum depth defined in your translation structure
const generatedKeys = generateKeys(4)
</script>
